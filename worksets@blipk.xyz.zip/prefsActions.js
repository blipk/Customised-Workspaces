const Me = imports.misc.extensionUtils.getCurrentExtension();

function restart() {
    imports.gi.Meta.restart(_("Restarting GNOME Shell..."))
}