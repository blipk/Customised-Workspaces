glib-compile-schemas schemas
cp -r ./ ~/.local/share/gnome-shell/extensions/worksets@blipk.xyz