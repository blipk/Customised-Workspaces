#!/bin/bash
cp -r ./worksets@blipk.xyz ~/.local/share/gnome-shell/extensions/