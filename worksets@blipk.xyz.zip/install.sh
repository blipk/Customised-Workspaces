#!/bin/bash
glib-compile-schemas ./worksets@blipk.xyz/schemas
cp -r ./worksets@blipk.xyz ~/.local/share/gnome-shell/extensions/